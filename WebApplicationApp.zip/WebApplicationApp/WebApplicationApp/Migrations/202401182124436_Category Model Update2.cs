﻿namespace WebApplicationApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CategoryModelUpdate2 : DbMigration
    {
        public override void Up()
        {
            DropIndex("dbo.Categories", new[] { "CategoryName" });
            DropIndex("dbo.Products", new[] { "ProductName" });
        }
        
        public override void Down()
        {
            CreateIndex("dbo.Products", "ProductName", unique: true);
            CreateIndex("dbo.Categories", "CategoryName", unique: true);
        }
    }
}
