﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Web.Mvc;
using PagedList.Mvc;
using PagedList;
using WebApplicationApp.Models;   

namespace WebApplicationApp.Controllers
{
    public class HomeController : Controller   
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        public ActionResult Index(int ? page)
        {
            var products = db.Products
         .Include(p => p.Category)
         .OrderBy(p => p.ProductId) 
         .ToList().ToPagedList(page ?? 1,10);
            return View(products);
            
        }
    }
}