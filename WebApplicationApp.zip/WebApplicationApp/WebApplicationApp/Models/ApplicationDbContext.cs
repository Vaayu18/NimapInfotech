﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApplicationApp.Models
{
    public class ApplicationDbContext : DbContext
    {  
        public ApplicationDbContext() :base("ApplicationDbContext")
        { 
        
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
  
            modelBuilder.Entity<Category>().Property(c => c.CategoryName).HasMaxLength(50).IsRequired();
            // One-to-Many relationship between Category and Product
            modelBuilder.Entity<Category>()
                .HasMany(c => c.Products)
                .WithRequired(p => p.Category)
                .HasForeignKey(p => p.CategoryId);

            base.OnModelCreating(modelBuilder);
        }
    }
}